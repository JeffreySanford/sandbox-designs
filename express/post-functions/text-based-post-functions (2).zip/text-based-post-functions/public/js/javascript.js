/*global window $*/
(function IFEE() {
    'use strict';

    $(function () {
        $('[data-toggle="tooltip"]').tooltip();
    });
}());